function incrementar() {
    let contador = 0;
    contador++;
    document.getElementById("contador").innerText = contador;
}
