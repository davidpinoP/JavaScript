function cambiarMensaje() {
    document.getElementById("mensaj").innerText = "¡Hola Mundo desde JavaScript!";
}
